import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';

const Home = () => {
  const [tours, setTours] = useState([]);

  useEffect(() => {
    const fetchTours = async () => {
      const res = await axios.get('/api/tours');
      setTours(res.data);
    };

    fetchTours();
  }, []);

  return (
    <div>
      <h1>Tours</h1>
      <ul>
        {tours.map(tour => (
          <li key={tour._id}>
            <Link to={`/tours/${tour._id}`}>{tour.title}</Link>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default Home;