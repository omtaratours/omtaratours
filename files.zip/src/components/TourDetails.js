import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useParams } from 'react-router-dom';
import { loadStripe } from '@stripe/stripe-js';
import { Elements, useStripe, useElements, CardElement } from '@stripe/react-stripe-js';

const stripePromise = loadStripe('your_stripe_public_key_here');

const TourDetails = () => {
  const { id } = useParams();
  const [tour, setTour] = useState(null);
  const [bookingId, setBookingId] = useState(null);
  const [clientSecret, setClientSecret] = useState('');

  useEffect(() => {
    const fetchTour = async () => {
      const res = await axios.get(`/api/tours/${id}`);
      setTour(res.data);
    };

    fetchTour();
  }, [id]);

  const handleBooking = async () => {
    const res = await axios.post('/api/bookings', { tourId: id }, {
      headers: {
        'x-auth-token': localStorage.getItem('token'),
      },
    });
    setBookingId(res.data._id);
    const paymentRes = await axios.post('/api/payments/create-payment-intent', { bookingId: res.data._id }, {
      headers: {
        'x-auth-token': localStorage.getItem('token'),
      },
    });
    setClientSecret(paymentRes.data.clientSecret);
  };

  if (!tour) return <div>Loading...</div>;

  return (
    <div>
      <h1>{tour.title}</h1>
      <p>{tour.description}</p>
      <p>Location: {tour.location}</p>
      <p>Price: ${tour.price}</p>
      <p>Date: {new Date(tour.date).toLocaleDateString()}</p>
      <button onClick={handleBooking}>Book Tour</button>
      {clientSecret && <Elements stripe={stripePromise}>
        <CheckoutForm clientSecret={clientSecret} bookingId={bookingId} />
      </Elements>}
    </div>
  );
};

const CheckoutForm = ({ clientSecret, bookingId }) => {
  const stripe = useStripe();
  const elements = useElements();
  const [error, setError] = useState('');
  const [success, setSuccess] = useState(false);

  const handleSubmit = async (event) => {
    event.preventDefault();

    const card = elements.getElement(CardElement);
    const result = await stripe.confirmCardPayment(clientSecret, {
      payment_method: {
        card,
        billing_details: {
          name: 'User Name',
        },
      },
    });

    if (result.error) {
      setError(result.error.message);
    } else {
      if (result.paymentIntent.status === 'succeeded') {
        await axios.put(`/api/bookings/${bookingId}`, { status: 'confirmed', paymentStatus: 'paid' }, {
          headers: {
            'x-auth-token': localStorage.getItem('token'),
          },
        });
        setSuccess(true);
      }
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <CardElement />
      <button type="submit" disabled={!stripe}>
        Pay
      </button>
      {error && <div>{error}</div>}
      {success && <div>Payment successful!</div>}
    </form>
  );
};

export default TourDetails;