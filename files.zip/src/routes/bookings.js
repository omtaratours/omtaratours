const express = require('express');
const Booking = require('../models/Booking');
const { verifyToken } = require('../middleware/auth');

const router = express.Router();

// Create a new booking
router.post('/', verifyToken, async (req, res) => {
  const { tourId } = req.body;
  const userId = req.user.id;

  try {
    const newBooking = new Booking({ user: userId, tour: tourId });
    await newBooking.save();
    res.status(201).json(newBooking);
  } catch (err) {
    res.status(500).json({ msg: 'Server error' });
  }
});

// Get bookings for a user
router.get('/my-bookings', verifyToken, async (req, res) => {
  const userId = req.user.id;

  try {
    const bookings = await Booking.find({ user: userId }).populate('tour');
    res.json(bookings);
  } catch (err) {
    res.status(500).json({ msg: 'Server error' });
  }
});

// Update booking status
router.put('/:id', verifyToken, async (req, res) => {
  const { id } = req.params;
  const { status } = req.body;

  try {
    const updatedBooking = await Booking.findByIdAndUpdate(id, { status }, { new: true });
    res.json(updatedBooking);
  } catch (err) {
    res.status(500).json({ msg: 'Server error' });
  }
});

module.exports = router;