const express = require('express');
const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);
const Booking = require('../models/Booking');
const { verifyToken } = require('../middleware/auth');

const router = express.Router();

// Create a payment intent
router.post('/create-payment-intent', verifyToken, async (req, res) => {
  const { bookingId } = req.body;

  try {
    const booking = await Booking.findById(bookingId).populate('tour');
    if (!booking) {
      return res.status(404).json({ msg: 'Booking not found' });
    }

    const paymentIntent = await stripe.paymentIntents.create({
      amount: booking.tour.price * 100, // Amount in cents
      currency: 'usd',
      metadata: {
        bookingId: booking._id.toString(),
        userId: booking.user.toString(),
      },
    });

    res.json({ clientSecret: paymentIntent.client_secret });
  } catch (err) {
    res.status(500).json({ msg: 'Server error' });
  }
});

module.exports = router;