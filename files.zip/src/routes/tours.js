const express = require('express');
const Tour = require('../models/Tour');
const { verifyToken, verifyOperator } = require('../middleware/auth');

const router = express.Router();

// Add a new tour
router.post('/', verifyToken, verifyOperator, async (req, res) => {
  const { title, description, location, price, type, date } = req.body;
  const operator = req.user.id;

  try {
    const newTour = new Tour({ title, description, location, price, type, date, operator });
    await newTour.save();
    res.status(201).json(newTour);
  } catch (err) {
    res.status(500).json({ msg: 'Server error' });
  }
});

// Update a tour
router.put('/:id', verifyToken, verifyOperator, async (req, res) => {
  const { id } = req.params;
  const { title, description, location, price, type, date } = req.body;

  try {
    const updatedTour = await Tour.findByIdAndUpdate(id, { title, description, location, price, type, date }, { new: true });
    res.json(updatedTour);
  } catch (err) {
    res.status(500).json({ msg: 'Server error' });
  }
});

// Delete a tour
router.delete('/:id', verifyToken, verifyOperator, async (req, res) => {
  const { id } = req.params;

  try {
    await Tour.findByIdAndDelete(id);
    res.json({ msg: 'Tour deleted' });
  } catch (err) {
    res.status(500).json({ msg: 'Server error' });
  }
});

// Search for tours
router.get('/search', async (req, res) => {
  const { location, type, date } = req.query;

  try {
    const tours = await Tour.find({
      location: new RegExp(location, 'i'),
      type: new RegExp(type, 'i'),
      date: { $gte: new Date(date) }
    });
    res.json(tours);
  } catch (err) {
    res.status(500).json({ msg: 'Server error' });
  }
});

module.exports = router;